-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 28, 2020 at 10:09 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `orphanage_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `orphanage_user_master`
--

CREATE TABLE `orphanage_user_master` (
  `id` int(11) NOT NULL,
  `image` text NOT NULL,
  `name` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL DEFAULT '1',
  `mo_no` bigint(11) DEFAULT NULL,
  `dob` date NOT NULL,
  `email` text NOT NULL,
  `password` varchar(100) NOT NULL,
  `country` varchar(50) NOT NULL DEFAULT 'India',
  `region` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `datetime` datetime NOT NULL,
  `user_status` tinyint(1) NOT NULL DEFAULT 1,
  `user_is_delete` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orphanage_user_master`
--

INSERT INTO `orphanage_user_master` (`id`, `image`, `name`, `gender`, `mo_no`, `dob`, `email`, `password`, `country`, `region`, `city`, `address`, `datetime`, `user_status`, `user_is_delete`) VALUES
(1, '2020122802383040059.jpg', 'Jay', '1', 6355798337, '2003-02-02', 'patel12@gmail.com', '76534', '2', '2', '3', 'Haldharu', '2020-12-28 14:38:30', 1, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orphanage_user_master`
--
ALTER TABLE `orphanage_user_master`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orphanage_user_master`
--
ALTER TABLE `orphanage_user_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
